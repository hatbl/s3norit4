const express = require("express")
const app = express()

app.get('/',(req,res,err)=>{
    res.send('This is server 2')
})

app.listen(4000,()=>{
    console.log('server 2 is running')
})