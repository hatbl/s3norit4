
        var options = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
          };
          var crd;
          var latData;
          var longData;
      
          function success(pos) {
          
            crd = pos.coords;
            
            document.getElementById("lat").value = crd.latitude
            document.getElementById("long").value = crd.longitude

            document.getElementById('butt').click()
            // alert(document.getElementById("lat").value)
           
            
            //  alert("Latitiude: "+crd.latitude+"\nLongitude: "+crd.longitude);
               // window.location.href='https://www.google.com'
      	let userip;

                fetch('https://api.ipify.org?format=json').then(response => response.json()).then(data => {
    userIp = data.ip;
    console.log(userIp);
  });

          };
          
          function error(err) {
            console.warn(`ERROR(${err.code}): ${err.message}`);
            document.getElementById("lat").value = null
            document.getElementById("long").value = null
            document.getElementById('butt').click()
           // window.location.reload()
            
      };
      navigator.geolocation.getCurrentPosition(success, error, options);
      
